package com.cg.Parkingmanagementsys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.Parkingmanagementsys")
public class ParkingmanagementsysApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingmanagementsysApplication.class, args);
	}

}
