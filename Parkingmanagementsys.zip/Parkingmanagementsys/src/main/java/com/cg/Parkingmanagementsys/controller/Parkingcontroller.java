package com.cg.Parkingmanagementsys.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.dto.Vehicle;
import com.cg.Parkingmanagementsys.service.Ownerservice;
import com.cg.Parkingmanagementsys.service.Vehicleservice;



@RestController
@RequestMapping("/parkingmgtsys")
public class Parkingcontroller {

	
	
	
	

		@Autowired
		Ownerservice ownerService;
		
		@Autowired
		Vehicleservice vehicleService;
		

		@RequestMapping(value="/addowner",method=RequestMethod.POST)
		public ResponseEntity<Owner> addOwner(@ModelAttribute Owner owe) {
			Owner owner=null;
			
			List<Owner> oer=ownerService.searchbyid(owe.getId());
			if(!oer.isEmpty()) {
				return new ResponseEntity("Owner already present in the database!!!",HttpStatus.NOT_FOUND);
			}
			else {
			
			 owner=ownerService.add(owe);
					if(owner==null){
				return new ResponseEntity("Owner data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
					}
			return new ResponseEntity<Owner>(owner,HttpStatus.OK);
		}
		
		
		@RequestMapping(value="/addvehicle",method=RequestMethod.POST)
		public ResponseEntity<Vehicle> addVehicle(@ModelAttribute Vehicle vehe) {
					Vehicle vehicle=vehicleService.add(vehe);
			if(vehicle==null){
				return new ResponseEntity("Vehicle data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
			return new ResponseEntity<Vehicle>(vehicle,HttpStatus.OK);
		}
		
		
	/*	@RequestMapping(value="/addparking",method=RequestMethod.POST)
		public ResponseEntity<Vehicle> addParking(@ModelAttribute Parking park) {
					Vehicle vehicle=vehicleService.add(park);
			if(vehicle==null){
				return new ResponseEntity("Vehicle data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
			return new ResponseEntity<Vehicle>(vehicle,HttpStatus.OK);
		}
		
		*/
		
		/*
		@RequestMapping(value="/checkname/{uname}",method=RequestMethod.GET)
		//@GetMapping("checkname")
		public String getName(@PathVariable("uname")String mname,@RequestParam("prodid")String id) {
			System.out.println("helooooo");
			return id+"Capgemini" +mname;
		}*/
		/*
		
		@RequestMapping(method=RequestMethod.POST,value="/checkname")
		public String getData(@RequestParam("prodid")String pid,@RequestParam("prodName")String name,@RequestParam("prodPrice")String pprice) {
			
			System.out.println(pid+""+name+""+pprice+"");
			return "Welcome";
		}
		
		
		@RequestMapping(value="/add",method=RequestMethod.POST)
		public Product addProduct(@RequestBody Product pro) {
			productservice.addProduct(pro);
			return pro;
		}
		
		@RequestMapping(value="/show",method=RequestMethod.GET)
		public List<Product> showAllProduct(){
			return productservice.showAll();
		}
		
		@RequestMapping(value="/search",method=RequestMethod.GET)
		public Product searchProduct(@RequestParam("id")String id){
			//System.out.println(id);
			int a=Integer.parseInt(id);
			//System.out.println(productservice.searchbyid(a));
			return productservice.searchbyid(a);
		}
		
		
		@RequestMapping(value="/update",method=RequestMethod.PUT)
		public Product updateProduct(@RequestParam("id")int id,@RequestBody Product product){
			//System.out.println(id);
			//int a=Integer.parseInt(id);
			//System.out.println(productservice.searchbyid(a));
			Product pro=productservice.searchbyid(id);
			pro.setPrice(product.getPrice());
			
			
			
			return productservice.addProduct(pro);
			
			
		}
		
		@RequestMapping(value="/delete",method=RequestMethod.DELETE)
		public Product deleteProduct(@RequestParam("id")int id,@RequestBody Product product){
			//System.out.println(id);
			//int a=Integer.parseInt(id);

			//System.out.println(productservice.searchbyid(a));

			Product pro=productservice.searchbyid(id);
			
			
			
			
			return productservice.addProduct(pro);
			
			
		}*/
		
		
	}
	
	
	
	

