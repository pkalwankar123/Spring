package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.Parkingmanagementsys.dto.Vehicle;
import com.cg.Parkingmanagementsys.exceptions.Invalidvehiclenumexception;



/*
 * Vehicleservice interface Service
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */

public interface Vehicleservice {


	public Vehicle add(Vehicle vehicle);
	public List<Vehicle> findBynumber(String number) throws Invalidvehiclenumexception;

}
