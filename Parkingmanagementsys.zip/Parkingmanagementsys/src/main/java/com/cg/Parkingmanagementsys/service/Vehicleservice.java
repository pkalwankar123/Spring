package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.Parkingmanagementsys.dto.Vehicle;





public interface Vehicleservice {


	public Vehicle add(Vehicle vehicle);
	/*public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException;*/

}
