package com.cg.Parkingmanagementsys.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Vehicle;



/*
 * Parkingtransactiondao interface Repository
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Vehicledao extends JpaRepository<Vehicle, Integer> {
	
	/*
	 * findByid: for finding the Vehicle
	 * return: Vehicle list corresponding to the id
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	public List<Vehicle> findBynumber(String number);

}
