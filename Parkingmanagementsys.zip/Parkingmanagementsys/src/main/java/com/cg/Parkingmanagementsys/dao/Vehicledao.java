package com.cg.Parkingmanagementsys.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Vehicle;




public interface Vehicledao extends JpaRepository<Vehicle, Integer> {
	


}
