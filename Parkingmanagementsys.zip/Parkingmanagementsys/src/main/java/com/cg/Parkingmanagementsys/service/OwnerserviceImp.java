package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Ownerdao;
import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.exceptions.Invalidownerdetailexception;
import com.cg.Parkingmanagementsys.exceptions.Invalidowneridexception;


/*
 * Ownerservice Service class implemented
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
@Service
@Transactional
public class OwnerserviceImp implements Ownerservice{
	static final Logger logger = Logger.getLogger(OwnerserviceImp.class); 	
	
	
	@Autowired
	Ownerdao owner;
	
	
	
	/*
	 * addid: for adding the owner
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	public Owner add(Owner owe) {
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		logger.info("Owner added successful");
		/*
		 * @return: return the data from the dao
		 *@author: Pradip kalwankar 
		 *@since: 2019-05-23
		 */
		return owner.save(owe);
	}
	
	
	
	/*
	 * searchbyid: for finding the id
	 * @Exception: throws exception if id not found to controller
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Override
	public List<Owner> Searchbyid(int id) throws Invalidownerdetailexception {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties");  
		if(!(owner.findByid(id).isEmpty())){
			logger.info("Searching owner....");
			throw new Invalidownerdetailexception("OOPS..Owner already present in the database found into the Database."
					+ " Please enter the valid Owner Id and try again!!");
			
		}else {
			/*
			 * @return: return the data from the dao
			 *@author: Pradip kalwankar 
			 *@since: 2019-05-23
			 */	
		return owner.findByid(id);
	}

	}
	

	
	/*
	 * searchbyid: for finding the id
	 * @Exception: throws exception if id not found to controller
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Override
public List<Owner> searchbyid(int id) throws Invalidowneridexception {
	// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
	if(owner.findByid(id).isEmpty()){
		
		throw new Invalidowneridexception("OOPS..Owner not found into the Database."
				+ " Please enter the valid Owner Id and try again!!");
		
	}else {
		logger.info("Searching owner....");
	
		/*
		 * @return: return the data from the dao
		 *@author: Pradip kalwankar 
		 *@since: 2019-05-23
		 */
		return owner.findByid(id);
}

}
}
