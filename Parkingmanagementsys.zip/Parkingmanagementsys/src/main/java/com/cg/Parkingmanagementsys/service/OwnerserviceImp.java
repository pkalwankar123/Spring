package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Ownerdao;
import com.cg.Parkingmanagementsys.dto.Owner;



@Service
@Transactional
public class OwnerserviceImp implements Ownerservice{
	
	@Autowired
	Ownerdao owner;
	
	public Owner add(Owner owe) {
		

		return owner.save(owe);
	}
	
/*public List<Owner> searchbyVehNo(int id) throws InvalidOwnerId{
		
		
		
		
		if(owner.findById(id).isEmpty()){
			
			throw new InvalidOwnerId("OOPS..Owner not found into the Database."
					+ " Please enter the valid Owner Id and try again!!");
			
		}else {
		
			return owner.findById(id);
	}

		
}
*/
@Override
public List<Owner> searchbyid(int id) {
	// TODO Auto-generated method stub
	return owner.findByid(id);
}

}
