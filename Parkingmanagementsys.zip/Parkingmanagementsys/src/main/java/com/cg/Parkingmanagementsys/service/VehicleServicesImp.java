package com.cg.Parkingmanagementsys.service;

import java.awt.Window.Type;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Vehicledao;
import com.cg.Parkingmanagementsys.dto.Vehicle;





@Service
@Transactional
public class VehicleServicesImp implements Vehicleservice {
	 private final static Logger LOGGER =  
             Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	 @Autowired
	 Vehicledao vehdao;

	
	
	public Vehicle add(Vehicle vehicle) {
		//LOGGER.info("Inside function ADD");
			
		return vehdao.save(vehicle);
	}

	/*public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException{
		
		
		
		
		if(vehdao.findByVehNo(vehNo).isEmpty()){
			//LOGGER.info("Inside function searchByVehno");
			//LOGGER.warning("YOU HAVE ENTERED THE WRONG DATA!!!!");
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
			
		}else {
		
			return vehdao.findByVehNo(vehNo);
	}

		
}*/
}
