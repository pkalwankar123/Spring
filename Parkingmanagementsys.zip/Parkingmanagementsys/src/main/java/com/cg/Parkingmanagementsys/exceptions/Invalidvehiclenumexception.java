package com.cg.Parkingmanagementsys.exceptions;

public class Invalidvehiclenumexception extends Exception {
public Invalidvehiclenumexception() {}
	
	public Invalidvehiclenumexception(String msg) {
		super(msg);
	}
	
}
