package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.Parkingmanagementsys.dto.Owner;




public interface Ownerservice {
public Owner add(Owner owe);
public List<Owner> searchbyid(int id);
}
