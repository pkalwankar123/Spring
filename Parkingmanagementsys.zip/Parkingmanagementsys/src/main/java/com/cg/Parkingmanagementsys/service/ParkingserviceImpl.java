package com.cg.Parkingmanagementsys.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Parkingdao;
import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.exceptions.Invalidowneridexception;
import com.cg.Parkingmanagementsys.exceptions.Invaliparkingidexception;
/*
 * ParkingserviceImpl Service class implemented
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */

@Service
@Transactional
public class ParkingserviceImpl implements Parkingservice {
	static final Logger logger = Logger.getLogger(ParkingserviceImpl.class); 	
	@Autowired
	Parkingdao parkdao;
	
	

	@Override
	public Parking add(Parking parking) {
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		logger.info("Parking added successful");
		return parkdao.save(parking);
	}



	

	/*
	 * searchbyid: for finding the id
	 * @Exception: throws exception if id not found to controller
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Override
	public List<Parking> searchbyid(int id) throws Invaliparkingidexception {
		// TODO Auto-generated method stub
			PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		if(parkdao.findByid(id).isEmpty()){
			logger.info("Searching Parking object....");
			throw new Invaliparkingidexception("OOPS..Parking not found into the Database."
					+ " Please enter the valid Parking Id and try again!!");
			
		}else {
			/*
			 * @return: return the data from the dao
			 *@author: Pradip kalwankar 
			 *@since: 2019-05-23
			 */	
		return parkdao.findByid(id);
	}

	}
	
	

	
	
}
