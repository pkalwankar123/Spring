package com.cg.Parkingmanagementsys.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.OwnerrepositoryImp;
import com.cg.demomvcjavaconfig.dao.ParkingrepositoryImpl;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.InvalidParkingId;
import com.cg.demomvcjavaconfig.exceptions.VehicleNotFoundException;
@Service
@Transactional
public class ParkingserviceImpl implements Parkingserviceinterface {
	@Autowired
	ParkingrepositoryImpl park;
	
	@Override
	public Parking add(Parking parking) throws InvalidOwnerId {
		
		return park.save(parking);
	}

	@Override
	public List<Parking> searchByid(int id) throws VehicleNotFoundException {
		// TODO Auto-generated method stub
		
		if(park.findById(id).isEmpty()){
			//LOGGER.info("Inside function searchByVehno");
			//LOGGER.warning("YOU HAVE ENTERED THE WRONG DATA!!!!");
			throw new VehicleNotFoundException("OOPS..Parking Not found into the Database."
					+ " Please enter the valid Parking id and try again!!");
			
		}else {
		
			return park.findById(id);
	}
		
		
	}

	
	
	
	
}
