package com.cg.Parkingmanagementsys.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;



public interface Ownerdao extends JpaRepository<Owner, Integer>{
	
	
	
	public List<Owner> findByid(int id);
	/* public List<Product> findByPriceBetween(double priceOne, double priceTwo);*/
}