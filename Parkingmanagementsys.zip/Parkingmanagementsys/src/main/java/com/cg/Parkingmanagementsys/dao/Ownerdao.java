package com.cg.Parkingmanagementsys.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;

/*
 * Ownerdao interface Repository
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */

public interface Ownerdao extends JpaRepository<Owner, Integer>{
	
	

/*
 * findByid: for finding the owner
 * return: owner list corresponding to the id
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
	public List<Owner> findByid(int id);
	
}