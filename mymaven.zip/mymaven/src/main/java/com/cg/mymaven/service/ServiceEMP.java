package com.cg.mymaven.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.mymaven.dao.Savingdata;
import com.cg.mymaven.dto.Employee;


public class ServiceEMP implements EmployeeService{

	Savingdata dao;
	
	public ServiceEMP() {
		
	dao=new Savingdata();
	}
	

	public void addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		//emp.setSalary(emp.getSalary()+(emp.getSalary()*0.1));
		dao.save(emp);
	}

	public List<Employee> searchByName(String name) {
		// TODO Auto-generated method stub
		
		
		return dao.findByName(name);
	}


	public Employee searchById(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		try {
			return dao.findById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	public List<Employee> showAll() throws SQLException {

		return dao.showAll();
	}


	public Employee update(Employee emp) {

		Employee empone=null;
		try {
			empone = dao.findById(emp.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(empone!=null) {
			empone.setSalary(emp.getSalary());
		}
		return empone;
	}


	public void sort() {
		// TODO Auto-generated method stub
		
	}

}
