package com.cg.mymaven.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.mymaven.dto.Employee;



		public interface EmployeeService {
			
			public void addEmployee(Employee emp) throws EmployeeException;
			
			public List<Employee> searchByName(String name);
			
			public Employee searchById(int id) throws EmployeeException ;
			
			public List<Employee> showAll() throws SQLException;
			
			public Employee update(Employee emp) throws EmployeeException;
			
			public void sort();
			

		

	}


