package com.cg.mymaven.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mymaven.dto.Employee;
import com.cg.mymaven.service.EmployeeException;
import com.cg.mymaven.util.DB;






public class Savingdata implements  InterCllectiondao{

	public Employee save(Employee emp) throws EmployeeException  {
		Connection con=DB.getConnection();
		String query_insert="Insert into student12 values(?,?,?)";
		PreparedStatement pstm=null;
		
		try {
		
			 pstm=con.prepareStatement(query_insert);
		pstm.setInt(1, emp.getId());
		pstm.setString(2, emp.getName());
		pstm.setDouble(3, emp.getSalary());
		
		
		pstm.executeUpdate();
		}
	catch(SQLException e) {
		e.printStackTrace();
			
		}
		
		finally {
			try {
				pstm.close();
				//con.close();
			}catch(SQLException e) {
//				e.printStackTrace();
			}
		}
		return null;
	}

	public List<Employee> findByName(String name) {
		
		
		
		
		return null;
	}

	public Employee findById(int id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> showAll() throws SQLException {
		
		List<Employee> emp=new ArrayList<Employee>();
		Connection con1;
		
		
		
		try {
			con1=DB.getConnection();
			String query_Show="Select id,name,salary from student12";
			PreparedStatement pstm;
			pstm=con1.prepareStatement(query_Show);
			ResultSet result=pstm.executeQuery();
			
			while(result.next()) {
				Employee emp1=new Employee();
				emp1.setId(result.getInt("id"));
				emp1.setName(result.getString("name"));
				emp1.setSalary(result.getDouble("salary"));
				
				emp.add(emp1);
				
			}
		
		
		
		}catch(EmployeeException e) {
			e.printStackTrace();
		}
		return emp;
	}


	

}

