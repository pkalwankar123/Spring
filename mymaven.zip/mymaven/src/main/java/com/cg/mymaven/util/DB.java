package com.cg.mymaven.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.imageio.stream.FileImageInputStream;

import com.cg.mymaven.service.EmployeeException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class DB {

static Connection conn;

	public static Connection getConnection() throws EmployeeException {
		
		Properties prop=new Properties();
		FileInputStream it=null;
		try {
			it=new FileInputStream("src/main/resources/jdbc.properties");
			
			prop.load(it);
			
			if(conn==null) {
if(prop!=null) {
	
	
	String driver=prop.getProperty("jdbc.driver");
	String url=prop.getProperty("jdbc.url");
	String uname=prop.getProperty("jdbc.username");
	String upass=prop.getProperty("jdbc.password");
	
	//Class.forName(driver);
	
	conn=DriverManager.getConnection(url,uname,upass);
}
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			
			throw new EmployeeException("File not found");
			
		}catch(IOException e) {
			e.printStackTrace();
			throw new EmployeeException("File not found");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}
}
