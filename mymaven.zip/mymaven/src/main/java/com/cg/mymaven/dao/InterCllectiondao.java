package com.cg.mymaven.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.mymaven.dto.Employee;
import com.cg.mymaven.service.EmployeeException;



public interface InterCllectiondao {
	public Employee save(Employee emp) throws EmployeeException;
	public List<Employee> findByName(String name);
	public Employee findById(int id) throws  SQLException;
	
	public List<Employee> showAll() throws SQLException;

}
