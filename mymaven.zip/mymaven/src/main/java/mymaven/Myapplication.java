package mymaven;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.mymaven.dto.Employee;
import com.cg.mymaven.service.EmployeeException;
import com.cg.mymaven.service.ServiceEMP;



public class Myapplication {

	
		static ServiceEMP service;
		
		
		
		
		
		public static void main(String[] args) throws EmployeeException {
			// TODO Auto-generated method stub

			Scanner sc=new Scanner(System.in);
			int choice=0;
			service=new ServiceEMP();
			do {
				
				printDeatils();
				System.out.println("enter the choice");
				choice=sc.nextInt();
				switch(choice){
					case 1: 
						System.out.println("Enter the employee ID");
					int id=sc.nextInt();
					System.out.println("Enter the employee Name");
					String name=sc.next();
					System.out.println("Enter the employee Salary");
					double Salary=sc.nextDouble();
					
					Employee emp=new Employee();
					emp.setId(id);
					emp.setName(name);
					emp.setSalary(Salary);
					
					service.addEmployee(emp);
					
					break;
					case 2:
					List<Employee> myList=null;
					try {
						myList = service.showAll();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						for(Employee empData:myList) {
							System.out.println("ID is"+empData.getId());
							System.out.println("Name is"+empData.getName());
							System.out.println("Salary is"+empData.getSalary());
							
						}
						
						
						break;
					case 3:
						System.out.println("enter the eployee name tghat you want to seazrch");
						String name1=sc.next();
						List<Employee> empSearch=service.searchByName(name1);
						for(Employee empe:empSearch) {
							System.out.println(""+empe.getId());
						}
						break;
					case 4:
						System.out.println("enter the ID");
						int ID=sc.nextInt();
						try {
							Employee empsearch=service.searchById(ID);
							if(empsearch!=null) {
								System.out.println(empsearch);
								System.out.println("enter the salary");
								double sal=sc.nextDouble();
								empsearch.setSalary(sal);
								service.update(empsearch);
							}
						}catch(EmployeeException e) {
							System.out.println(e.getMessage());
						}
						
						break;
				}
			}while(choice!=6);
			
			
			/*
			List<String> myList=new LinkedList();
		myList.add("A");
		myList.add("B");
		myList.add("C");
		myList.add("c");
		//myList.add(false);
		//List<Integer> myList1=new LinkedList<Integer>();
		
		//myList1.add((char) 12);
		//myList1.addAll("asd,jhsdfjk");
		//System.out.println(myList);
		//System.out.println(myList1);
		for(String list:myList) {
			System.out.println(myList);
		}
		
		System.out.println("-------------------");
		
		/*
		Iterator<String> it=myList.iterator();
		while(it.hasNext()) {
			//it.remove();
			
			//System.out.println();
		}
		
		*/
		}
		
		public static void printDeatils() {
			System.out.println("1. Add Employee");
			System.out.println("2. Show All employee");
			System.out.println("3. update employee");
			System.out.println("4. Search Employee");
			System.out.println("5. Sort");
		}

}
