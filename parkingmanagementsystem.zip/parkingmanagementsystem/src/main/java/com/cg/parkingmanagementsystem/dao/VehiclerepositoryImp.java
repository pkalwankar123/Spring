package com.cg.parkingmanagementsystem.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.parkingmanagementsystem.dbutil.Dbutil;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;


public class VehiclerepositoryImp implements Vehiclerepositoryinterface{

	EntityManager em;
	public VehiclerepositoryImp() {
		em=Dbutil.em;
	}
	
	
	public Vehicle save(Vehicle vehicle)
			throws InvaliddetailId, SQLException, InvalidOwnerId {
		
		
		int owner_id=vehicle.getOwner().getId();
		
		
		
		
		Query queryOne  = em.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
		if(!(owner.isEmpty())) {
			em.getTransaction().begin();
			em.persist(vehicle);
			//em.merge(vehicle);
			em.getTransaction().commit();
			//em.close();
			
		}
		//em.persist(vehicle.getOwner());
		
		

		else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		 
		
		return vehicle;
	}

	public List<Vehicle> findByVehNo(String vehNumber)
			throws VehicleNotFoundException, SQLException {
		//List<Vehicle> depts;
		Query query  = em.createQuery("Select a From Vehicle a where vehicle_number= :vehNumber");
		 
		
		 List<Vehicle> depts=query.setParameter("vehNumber", vehNumber).getResultList();
		// veh.setnumber(number);
		// veh.setnumber(number);
		// depts.Vehicle.class).getResultList()

		
		return depts;
	}

	
}
