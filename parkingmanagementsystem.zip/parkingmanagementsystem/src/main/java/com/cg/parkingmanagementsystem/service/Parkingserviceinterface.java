package com.cg.parkingmanagementsystem.service;

import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;

public interface Parkingserviceinterface {

	public void addParking(Parking parking) throws InvaliddetailId, InvalidOwnerId;
	
}
