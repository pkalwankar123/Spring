package com.cg.parkingmanagementsystem.exceptions;

public class invaliddetailexcepion extends Exception {

	public invaliddetailexcepion(){}
	
	public invaliddetailexcepion(String message){
		super(message);
	}
	
}
