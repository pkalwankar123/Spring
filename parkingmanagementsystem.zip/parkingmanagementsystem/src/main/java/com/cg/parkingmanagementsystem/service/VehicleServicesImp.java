package com.cg.parkingmanagementsystem.service;

import java.awt.Window.Type;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

import com.cg.parkingmanagementsystem.dao.VehiclerepositoryImp;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;
import com.mysql.fabric.xmlrpc.base.Value;





public class VehicleServicesImp implements Vehicleserviceinterface {
	 private final static Logger LOGGER =  
             Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	VehiclerepositoryImp vehdao;

	public VehicleServicesImp(){
		vehdao=new VehiclerepositoryImp();
	}
	
	
	public void add(Vehicle vehicle) throws InvaliddetailId, SQLException, InvalidOwnerId {
		LOGGER.info("Inside function ADD");
			vehdao.save(vehicle);
		
	}

	public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException, SQLException {
		
		
		
		if(vehdao.findByVehNo(vehNo).isEmpty()){
			LOGGER.info("Inside function searchByVehno");
			LOGGER.warning("YOU HAVE ENTERED THE WRONG DATA!!!!");
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
			
		}else
		
			return vehdao.findByVehNo(vehNo);
	}


}
