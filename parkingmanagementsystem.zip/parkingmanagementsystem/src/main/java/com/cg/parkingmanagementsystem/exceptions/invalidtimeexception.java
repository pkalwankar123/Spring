package com.cg.parkingmanagementsystem.exceptions;

public class invalidtimeexception extends Exception {

	public invalidtimeexception(){}
	
	public invalidtimeexception(String message){
		super(message);
	}
}
