package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.dao.ParkingslotrepositoryImp;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;

public class ParkingslotserviceImp implements Parkingslotinterface{


	ParkingslotrepositoryImp parkslot;
	
	public ParkingslotserviceImp(){
		parkslot=new ParkingslotrepositoryImp();
	}
	
	
	public void createParkingslot(Parkingslot parkingslot) throws InvaliddetailId, InvalidOwnerId {
		// TODO Auto-generated method stub
		parkslot.create(parkingslot);
	}
	
	public List<Parkingslot> searchByid(int id) throws ParkingNotFoundException, SQLException{
		// TODO Auto-generated method stub
		
		
		if(parkslot.findByid(id).isEmpty()){
			throw new ParkingNotFoundException("OOPS..Parkingslot Not found into the Database."
					+ " Please enter the valid slotID and try again!!");
		
		}else
		
			return parkslot.findByid(id);
	}

		
		
	

}

