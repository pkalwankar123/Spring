package com.cg.parkingmanagementsystem.ui;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Logger;

import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;
//import com.cg.parkingmanagementsystem.exception.InvalidOwnerId;
//import com.cg.parkingmanagementsystem.exception.InvaliddetailId;
//import com.cg.parkingmanagementsystem.exception.duplicateaddressuserexception;
//import com.cg.parkingmanagementsystem.util.Dbutil;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.Invaliddateexcepion;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;
import com.cg.parkingmanagementsystem.exceptions.VehicleNotFoundException;
import com.cg.parkingmanagementsystem.exceptions.Invaliddateexcepion;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;
import com.cg.parkingmanagementsystem.service.OwnerserviceImp;
import com.cg.parkingmanagementsystem.service.ParkingserviceImp;
import com.cg.parkingmanagementsystem.service.ParkingslotserviceImp;
import com.cg.parkingmanagementsystem.service.ParkingtransserviceImp;
import com.cg.parkingmanagementsystem.service.VehicleServicesImp;

public class Myapplication {
	 private final static Logger LOGGER =  
             Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	static int addid=100;
	public static void main(String[] args) throws SQLException, ParseException {
		 
		//object of all service classes
				
				VehicleServicesImp vehsservice=new VehicleServicesImp();
				ParkingserviceImp parkservice=new ParkingserviceImp();
				ParkingslotserviceImp parkslotservice=new ParkingslotserviceImp();
				ParkingtransserviceImp parktrans=new ParkingtransserviceImp();
				OwnerserviceImp oweserv=new OwnerserviceImp();
			
				
				Owner owew=new Owner();
				Random random=new Random();
				

		int choice=0;
		do{
				Scanner sc=new Scanner(System.in);
				System.out.println("================================================");
				System.out.println();
				System.out.println("========= Parking Management System ===========");
				System.out.println();
				System.out.println("================================================");
				System.out.println("=============== WELCOME ========================");
				System.out.println("1. Add Owner");
				System.out.println("2. Add Vehicles");
				System.out.println("3. Search Vehicles");
				System.out.println("4. Add Parking Location");
				System.out.println("5. Add Parkingslot");
				
				System.out.println("6. Assign Parking");
				System.out.println("7. Exit");
				System.out.println();
				System.out.println("================================================");
			
				choice=sc.nextInt();
				
				
				switch(choice){
				//for adding vehicle  called add(owew)
				case 1: 
					//System.out.println("enter the owner id");
					int id=random.nextInt(1000)+1;
				
					System.out.println("enter the name");
					String owname=sc.next();
					System.out.println("enter the Mobile number");
					String mobno=sc.next();
					//System.out.println("enter the address id");
					int addid=random.nextInt(1000)+1;
					//addid++;
					System.out.println("enter the house no");
					String houseno=sc.next();
					System.out.println("enter the Street");
					String street=sc.next();
					System.out.println("enter the city");
					String city=sc.next();
					System.out.println("enter the Pincode");
					int pincode=sc.nextInt();
					
					//address object for setting into owner
					Address add=new Address(addid,houseno,street,city,pincode);
					
					
					owew.setId(id);
					owew.setName(owname);
					owew.setMobNo(new BigInteger(mobno));
					owew.setAddress(add);
					try {
						oweserv.add(owew);
					} catch (Duplicateaddressuserexception e1) {
						
						System.out.println(e1.getMessage());
					break;
					} catch (SQLException e) {

						e.printStackTrace();
						break;
					}
					

					
					System.out.println("================================");
					System.out.println();
					System.out.println("Owner Added successfully!!!!");
					System.out.println();
					System.out.println("=================================");
				
					
					
					
					
					break;	
					//for adding vehicle  called add(vehice12)
				case 2: 
					
					
					char ch;
					System.out.println("enter the owner id");
					int owwid=sc.nextInt();
					
				do{
					
					//System.out.println("enter the vehicle id");
					int vehid=random.nextInt(1000)+1;
					
					System.out.println("enter vehicle number");
					String vehno=sc.next();
					System.out.println("enter vehicle desciption");
					String vedesc=sc.next();
					
			
					Owner owenew=new Owner(owwid,null,null,null,null);
					
					
					
					
					Vehicle vehice12=new Vehicle(vehid,vehno,vedesc,owenew);
							
						try {
							
								vehsservice.add(vehice12);
							} catch (InvaliddetailId e) {
								System.out.println(e.getMessage());
								break;		} catch (SQLException e) {

									LOGGER.info(e.getMessage());
							} catch (InvalidOwnerId e) {
									// TODO Auto-generated catch block
								System.out.println(e.getMessage());
								break;
								}
						
							
							
						
						
						System.out.println("Do you want to assign another vehicle??  Y/N");
						ch=sc.next().charAt(0);
						System.out.println();
				}while(ch=='Y'||ch=='y');
						
						
						
						System.out.println("================================");
						System.out.println();
						//System.out.println("Vehicles Added successfully!!!!");
						System.out.println();
						System.out.println("=================================");
						
						
						break;
						//for searching vehicle searchbyVehNo called
					case 3:
						System.out.println();
						System.out.println("=================================");
						System.out.println("Enter Vehicle number that you want too search");
						String vehNo=sc.next();
					Vehicle vehicle;
					try {
						List<Vehicle> vehicles = vehsservice.searchbyVehNo(vehNo);
						
						System.out.println("Here is your Vehicle detail...");
						System.out.println();
for(Vehicle vehicleee:vehicles) {
						System.out.println(vehicleee.vehicleDetails());
}
						
					} catch (VehicleNotFoundException e) {
						
						System.out.println(e.getMessage());
						LOGGER.info(e.getMessage());
						break;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						LOGGER.info(e.getMessage());
					}
					System.out.println("=================================");
						break;
						//for adding vehicle  called addParking(parki)
					case 4:
						System.out.println("=================================");
					
						
						
						int pid=random.nextInt(1000)+1;
						
					
						System.out.println("enter the Parking Location");
						String plocation=sc.next();
						
						System.out.println("enter Owner ID");
						int powid=sc.nextInt();
						Owner owenew=new Owner(powid,null,null,null,null);
						
						Parking parki=new Parking(pid,plocation,owenew);
				
						
						
						
						
						try {
							parkservice.addParking(parki);
						} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
							
							System.out.println(e.getMessage());
							break;
						} catch (InvalidOwnerId e) {
							System.out.println(e.getMessage());
							break;
						}
					
						
						System.out.println("Parking location Added successfullly!!!");
						System.out.println();
						/*for(Parking owe:DButil.parking){
							System.out.println("Parking id:- "+owe.getId());
							System.out.println("Parking Location:- "+owe.getLocation());
							
							
						System.out.println("Owner Detail:- "+owe.getOwner().getOwnerDetails());
						System.out.println("=================================");*/
						
					System.out.println("Parking created successfully!!!");
					
					System.out.println("=================================");
						break;
						//for adding vehicle  called createParkingslot(parks)
						
						case 5:
			System.out.println("=================================");
			
			System.out.println("=================================");

			System.out.println("enter the Parking id");
			int pd=sc.nextInt();

			
			
			
			int psid=random.nextInt(1000)+1;
			
			System.out.println("enter the start date for Parkingslot");
			String startdate=sc.next();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	        LocalDate startdate1 = LocalDate.parse(startdate, formatter);

	        java.sql.Date sd=java.sql.Date.valueOf(startdate1);
	        
			if(validatenew(startdate)) {
				if((isvalidatenew(startdate)) || (isToday(startdate))) {
				System.out.println();
			}else {
				try {
					throw new Invaliddateexcepion("OOPs...you have entered the earlier date!!"
							+ "Please try again with valid date!!!");
				} catch (Invaliddateexcepion e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
				}
			else {
				try {
					throw new Invaliddateexcepion("OOPs...please check the date that you have entered!!"
							+ "Please try again with valid date");
				} catch (Invaliddateexcepion e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}			}
			
			

		        		        
		        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		        
		        
		        System.out.println("enter the end date for Parkingslot");
				String enddate=sc.next();
			
				
				if(validatenew(enddate)) {
					if((isvalidatenew(enddate)) || (isToday(enddate))) {
					System.out.println();
				}else {
					try {
						throw new Invaliddateexcepion("OOPs...you have entered the earlier date!!"
								+ "Please try again with valid date!!!");
					} catch (Invaliddateexcepion e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						break;
					}
				}
					}
				else {
					try {
						throw new Invaliddateexcepion("OOPs...please check the date that you have entered!!"
								+ "Please try again with valid date");
					} catch (Invaliddateexcepion e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						break;
					}			}
				
				
				
				LocalDate enddate1 = LocalDate.parse(enddate, formatter1);
				//LocalDate formatDateTime = LocalDate.parse(enddate, formatter);
			

			
			
			
				DateTimeFormatter formatternew = DateTimeFormatter.ofPattern("HH:mm");
			
			System.out.println("Enter time slot, start time in hrs and minutes:");
			System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
		String starttime=sc.next();
		LocalTime  starttime1= LocalTime.parse(starttime, formatternew);

		

		System.out.println("Till how many hrs you want to create ParkingSlot");
		int patternOne=sc.nextInt();


		LocalTime endTime1 = starttime1.plusHours(patternOne);
			
		
		//LocalTime endTime1 = LocalTime.parse(patternOne, formatternew);

		



		
		java.sql.Date ed=java.sql.Date.valueOf(enddate1);
		
		
		Time st=Time.valueOf(starttime1);
		
		
		Time et=Time.valueOf(endTime1);
		
		//Myapplication my=new Myapplication();
		//my.validateq(sd);
				
				 //if (validateq(sd)) { System.out.println(); } else { System.out.println("no");
				 // break; }
				

		Parking pars=new Parking();
		pars.setId(pd);

		Parkingslot parks=new Parkingslot(psid,pars,sd,ed,st,et);

				
			
			

			
			
			
					
						try {
							parkslotservice.createParkingslot(parks);
						} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
							break;
						} catch (InvalidOwnerId e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
							break;
						}
					
			
						System.out.println("Parking slot created successfullly");
						System.out.println();
						/*for(Parkingslot owe:DButil.parkingslot){
							System.out.println("ParkingSlot ID:- "+owe.getId());
							System.out.println("Parkingslot for "+owe.getParking());
							System.out.print("ParkingSlot creator detail:- "+owe.getParking().getOwner().ownerDetails());
							System.out.println();
							System.out.println("Start date of parkingslot:- "+owe.getStartDate());
							System.out.println("End date of parkingslot:- "+owe.getEndDate());
							System.out.println("Start time of parkingslot:- "+owe.getStartTime());
							System.out.println("End time of parkingslot:- "+owe.getEndTime());						
							System.out.println();
							System.out.println("=================================");
						}*/
						break;
						
						//for adding vehicle  called bookParking(parktranss)
							
		case 6:
					char ch1;
					do {
				
			
			System.out.println("=================================");
			System.out.println();
			//System.out.println("Enter parking transaction id");
			int pid1=random.nextInt(1000)+1;
			
			System.out.println("Enter parkingslot id");
			int id1=sc.nextInt();
			//System.out.println();
			System.out.println("Enter Vehicle number");
			String vehNoone=sc.next();

			
			System.out.println("enter the start date for Parkingslot");
			String startdateOne=sc.next();
			 
			

			if(validatenew(startdateOne)) {
				if((isvalidatenew(startdateOne)) || (isToday(startdateOne))) {
				System.out.println();
			}else {
				try {
					throw new Invaliddateexcepion("OOPs...you have entered the earlier date!!"
							+ "Please try again with valid date!!!");
				} catch (Invaliddateexcepion e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					break;
				}
			}
				}
			else {
				try {
					throw new Invaliddateexcepion("OOPs...please check the date that you have entered!!"
							+ "Please try again with valid date");
				} catch (Invaliddateexcepion e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					break;
				}			}
			

		        DateTimeFormatter formatterOne = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		        LocalDate startdateOnenew = LocalDate.parse(startdateOne, formatterOne);
		        
		        DateTimeFormatter formatternew1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		        
		        
		        System.out.println("enter the end date for Parkingslot");
				String enddateOne=sc.next();
			
				
				if(validatenew(enddateOne)) {
					if((isvalidatenew(enddateOne)) || (isToday(enddateOne))) {
					System.out.println();
				}else {
					try {
						throw new Invaliddateexcepion("OOPs...you have entered the earlier date!!"
								+ "Please try again with valid date!!!");
					} catch (Invaliddateexcepion e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						break;
					}
				}
					}
				else {
					try {
						throw new Invaliddateexcepion("OOPs...please check the date that you have entered!!"
								+ "Please try again with valid date");
					} catch (Invaliddateexcepion e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						break;
					}			}
				
				
				LocalDate enddateOnenew = LocalDate.parse(enddateOne, formatternew1);
				//LocalDate formatDateTime = LocalDate.parse(enddate, formatter);
			

			
			
			
				DateTimeFormatter formatternew2 = DateTimeFormatter.ofPattern("HH:mm");
			
			System.out.println("Enter time slot, start time in hrs and minutes:");
			System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
		String starttimenew=sc.next();
		LocalTime  starttimenew1= LocalTime.parse(starttimenew, formatternew2);

		

		System.out.println("Till how many hrs you want to create ParkingSlot");
		int patternOnenew=sc.nextInt();


		LocalTime endTimenew1 = starttimenew1.plusHours(patternOnenew);
		


		
		

			
			
			
			
			
			System.out.println();
		Vehicle vehee=new Vehicle();
			
			Parkingslot paki=new Parkingslot();

			List<Vehicle> vehicle1;
			try {
				vehicle1 = vehsservice.searchbyVehNo(vehNoone);
for(Vehicle vehic:vehicle1) {
					if(vehic.getnumber().equals(vehNoone)){
						vehee=vehic;
}}
			} catch (VehicleNotFoundException e1) {

				System.out.println(e1.getMessage());
				break;
			} 
			
			List<Parkingslot> park;
			try {
				park = parkslotservice.searchByid(id1);
				for(Parkingslot par:park){
					if(par.getId()==id1) {
						
						paki=par;
						
								}
				}
			} catch (ParkingNotFoundException e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
				break;
			}
			
				
			
			try {
				if(vehee.getnumber()==null || paki.getId()!=id1){
				throw new invaliddetailexcepion("OOPS!!..You have entered the wrong ID or Vehicle Number."
						+ "Please enter the valid detail and try again!!!");}
			} catch (invaliddetailexcepion e) {
				
				System.out.println(e.getMessage());
				break;
			}
			//LocalTime pstartTime1 = LocalTime.of(patternp, patterntwop);
			//LocalTime pendTime1 = pstartTime1.plusHours(patternOnep);




			//LocalDate pstartDate1 = LocalDate.of(pyear,pmonth,pday);
			//LocalDate pendDate1 = LocalDate.of(pyear1,pmonth1,pday1);
			java.sql.Date psd=java.sql.Date.valueOf(startdateOnenew);
			
			java.sql.Date ped=java.sql.Date.valueOf(enddateOnenew);
			
			
			Time pst=Time.valueOf(starttimenew1);
			
			
			Time pet=Time.valueOf(endTimenew1);
			


			Parktransaction parktranss=new Parktransaction(pid1,paki,vehee,psd,ped,pst,pet);
			
			
			
					
						
							try {
								parktrans.bookParking(parktranss);
							} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
								// TODO Auto-generated catch block
								System.out.println(e.getMessage());
								break;
							}
						
						
					 catch (invaliddetailexcepion e) {
						
						System.out.println(e.getMessage());
						break;
					}
						
						System.out.println("Parking assigned to below users successfullly..!!!");
						
						/*for(Parktransaction owe:DButil.parktrans){
							System.out.println("Parking transaction ID:- "+owe.getId());
							System.out.println(owe.getPk());
							System.out.print(owe.getVeh().vehicleDetails());
							System.out.println();
							System.out.println("Start date:- "+owe.getStartDate());
							System.out.println("End date:- "+owe.getEndDate());
							System.out.println("Start Time:- "+owe.getStartTime());
							System.out.println("End Time:- "+owe.getEndTime());
							System.out.println();			
						}*/
						System.out.println("================================================");
						
						System.out.println("Do you want to assign another vehicle??  Y/N");
						ch=sc.next().charAt(0);
						System.out.println();
				}while(ch=='Y'||ch=='y');
						break;
					
		case 7:
			System.out.println("======= Thank you ======");
			System.exit(0);
					break;
					
					default:
						System.out.println("Oops..Invalid input."
								+ "Please enter the correct choice from the list!!!");
				}
				
			}while(choice!=7);

		}

	/*
	 * 
	 * static int MAX_VALID_YR = 9999; static int MIN_VALID_YR = 1800;
	 * 
	 * // Returns true if // given year is valid. static boolean isLeap(int year) {
	 * // Return true if year is // a multiple of 4 and not // multiple of 100. //
	 * OR year is multiple of 400. return (((year % 4 == 0) && (year % 100 != 0)) ||
	 * (year % 400 == 0)); }
	 * 
	 * // Returns true if given // year is valid or not. static boolean
	 * isValidDate(Date date) { // If year, month and day // are not in given range
	 * if (date.getYear() > MAX_VALID_YR || date.getYear() < MIN_VALID_YR) return
	 * false; if (date.getMonth() < 1 || date.getMonth()> 12) return false; if
	 * (date.getDay() < 1 || date.getDay() > 31) return false;
	 * 
	 * // Handle February month // with leap year if (date.getMonth() == 2) { if
	 * (isLeap(date.getYear())) return (date.getDay() <= 29); else return
	 * (date.getDay() <= 28); }
	 * 
	 * // Months of April, June, // Sept and Nov must have // number of days less
	 * than // or equal to 30. if (date.getMonth() == 4 || date.getMonth() == 6 ||
	 * date.getMonth() == 9 || date.getMonth() == 11) return (date.getDay() <= 30);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * return true; }
	 * 
	 */	/*
	 * static boolean validateq(Date date) {
	 * 
	 * if(date.getYear()>=1900 && date.getYear()<=9999) { //check month
	 * if(date.getMonth()>=1 && date.getMonth()<=12) { //check days
	 * if((date.getDay()>=1 && date.getDay()<=31) && (date.getMonth()==1 ||
	 * date.getMonth()==3 || date.getMonth()==5 || date.getMonth()==7 ||
	 * date.getMonth()==8 || date.getMonth()==10 || date.getMonth()==12)) return
	 * true; else if((date.getDay()>=1 && date.getDay()<=30) && (date.getMonth()==4
	 * || date.getMonth()==6 || date.getMonth()==9 || date.getMonth()==11)) return
	 * true; else if((date.getDay()>=1 && date.getDay()<=28) &&
	 * (date.getMonth()==2)) return true; else if(date.getDay()==29 &&
	 * date.getMonth()==2 && (date.getYear()%400==0 ||(date.getYear()%4==0 &&
	 * date.getYear()%100!=0))) return true; else return false; } else { return
	 * false; } } return false;
	 * 
	 * }
	 */

	
	static boolean validatenew(String date) {
		SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		datef.setLenient(false);
		try {
			datef.parse(date.trim());
		}
		catch(ParseException p) {
			return false;
			
		}
		
		return true;
	}
	static boolean isvalidatenew(String date) throws ParseException {
		SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		Date date1=datef.parse(date);
		
		return new Date().before(date1);
			}
	static boolean isToday(String date) throws ParseException {
SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		Date date1=datef.parse(date);
		
		return new Date().equals(date1);
		
	}
// Driver code 

	private static boolean isSameDay(Date date1, Date date2) {
		// TODO Auto-generated method stub
		Calendar cal1=Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2=Calendar.getInstance();
		cal1.setTime(date2);
		
		
		return isSameDay(cal1,cal2);
	}

	private static boolean isSameDay(Calendar cal1, Calendar cal2) {
		// TODO Auto-generated method stub
		return (cal1.get(Calendar.YEAR)==cal2.get(Calendar.YEAR)&&
				cal1.get(Calendar.MONTH)==cal2.get(Calendar.MONTH)&&
				cal1.get(Calendar.DAY_OF_MONTH)==cal2.get(Calendar.DAY_OF_MONTH));
	}
} 

