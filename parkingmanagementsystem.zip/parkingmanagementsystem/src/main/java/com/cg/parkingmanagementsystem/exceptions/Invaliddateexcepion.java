package com.cg.parkingmanagementsystem.exceptions;

public class Invaliddateexcepion extends Exception {
public Invaliddateexcepion() {
	
}

public Invaliddateexcepion(String msg) {
	super(msg);
}
}
