package com.cg.parkingmanagementsystem.dto;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//Entity class created

@Entity
@Table(name="Parktransaction")
	public class Parktransaction {
		//Attributes//
	@Id
	@Column(name="parkingtransaction_id")
		private int id;
	
	
	@OneToOne(cascade=CascadeType.MERGE)
    @JoinColumn(name="parkingslot_id")
		private Parkingslot parkingslot;
	
	@OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="vehicle_id")
		private Vehicle vehicle;
	
	@Column(name="startdate")
		private Date startDate;
	@Column(name="enddate")
		private Date endDate;
		
	@Column(name="starttime")
		private Time startTime;
		
	@Column(name="endtime")	
	private Time endTime;

		//Constructors//
		public Parktransaction() {}

		public Parktransaction(int id, Parkingslot parkingslot, Vehicle vehicle, Date startDate, Date endDate,
				Time startTime, Time endTime) {
			super();
			this.id = id;
			this.parkingslot = parkingslot;
			this.vehicle = vehicle;
			this.startDate = startDate;
			this.endDate = endDate;
			this.startTime = startTime;
			this.endTime = endTime;
		}

		
		//Getter and setters//
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Parkingslot getparkingslot() {
			return parkingslot;
		}

		public void setPk(Parkingslot parkingslot) {
			this.parkingslot = parkingslot;
		}

		public Vehicle getvehicle() {
			return vehicle;
		}

		public void setVeh(Vehicle vehicle) {
			this.vehicle = vehicle;
		}

		public Date getStartDate() {
			return startDate;
		}

		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}

		public Date getEndDate() {
			return endDate;
		}

		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}

		public Time getStartTime() {
			return startTime;
		}

		public void setStartTime(Time startTime) {
			this.startTime = startTime;
		}

		public Time getEndTime() {
			return endTime;
		}

		public void setEndTime(Time endTime) {
			this.endTime = endTime;
		}

		@Override
		public String toString() {
			return "Parktransaction [id=" + id + ", pk=" + parkingslot + ", veh=" + vehicle + ", startDate=" + startDate + ", endDate="
					+ endDate + ", startTime=" + startTime + ", endTime=" + endTime + "]";
		}

		
	
	}

