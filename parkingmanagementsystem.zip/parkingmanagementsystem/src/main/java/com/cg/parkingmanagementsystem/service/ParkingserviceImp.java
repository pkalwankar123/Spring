package com.cg.parkingmanagementsystem.service;

import com.cg.parkingmanagementsystem.dao.ParkingrepositoryImp;
import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;

public class ParkingserviceImp implements Parkingserviceinterface{

	
	ParkingrepositoryImp parkdao;
	public ParkingserviceImp(){
		parkdao=new ParkingrepositoryImp();
	}
	
	
	public void addParking(Parking parking) throws InvaliddetailId, InvalidOwnerId {

		parkdao.save(parking);
	}


}

