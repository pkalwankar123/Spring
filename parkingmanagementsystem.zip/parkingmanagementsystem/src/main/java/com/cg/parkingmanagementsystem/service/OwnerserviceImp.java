package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dao.OwnerrepositoryImp;
import com.cg.parkingmanagementsystem.dto.Address;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;

public class OwnerserviceImp implements Ownerserviceinterface{
	OwnerrepositoryImp owed;
	static int id=100;
	static int addid=100;
	public OwnerserviceImp() {
	owed=new OwnerrepositoryImp();
	
	}
	public Owner add(Owner owe) throws Duplicateaddressuserexception, SQLException {
		

		return owed.save(owe);
	}
	
	
}
