package com.cg.ProductSpringBoot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.ProductSpringBoot.dto.Product;

@Repository
public class ProductdaoImpl implements Productdao{

	List<Product> myList=new ArrayList<>();
	
	@Override
	public Product save(Product pro) {
		
		myList.add(pro);
		return pro;
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Product findbyid(int id) {
	
		//Product prodo=new Product();
		for(Product pr:myList) {
			if(pr.getId()==id) {
				return pr;
				
			}
			
		}
		
		
		
		return null;
	}

}
