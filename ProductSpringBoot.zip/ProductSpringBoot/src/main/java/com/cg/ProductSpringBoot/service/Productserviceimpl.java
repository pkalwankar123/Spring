package com.cg.ProductSpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProductSpringBoot.dao.Productdao;
import com.cg.ProductSpringBoot.dto.Product;
@Service
public class Productserviceimpl implements Productservice {
@Autowired
	Productdao productDao;
	
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productDao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productDao.showAll();
	}

	@Override
	public Product searchbyid(int id) {
		// TODO Auto-generated method stub
		return productDao.findbyid(id);
	}

}
