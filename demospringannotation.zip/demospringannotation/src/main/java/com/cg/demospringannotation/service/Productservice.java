package com.cg.demospringannotation.service;

import java.util.List;

import com.cg.demospringannotation.dto.Product;

public interface Productservice {

public void addProduct(Product prod);

public List<Product> showAll();

}
