package com.cg.demospringannotation.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.demospringannotation.dto.Product;

@Component("Productdao")
public class Productdaoimp implements Productdao {

	List<Product> productList=new ArrayList<Product>();
	
	public void save(Product prod) {
		productList.add(prod);		
	}

	public List<Product> showAll() {

		return productList;
	}

}
