package com.cg.demospringannotation.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demospringannotation.dto.Product;
import com.cg.demospringannotation.dto.Transaction;

@Configuration
@ComponentScan("com.cg.demospringannotation")
public class JavaConfig {
	
	
	

}
