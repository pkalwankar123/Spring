package com.cg.springmvcdem.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdem.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao{
List<Product> myList=new ArrayList<Product>();
	
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		entitymanager.persist(pro);
		entitymanager.flush();
		return pro;
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		
		Query query=entitymanager.createQuery("FROM Product");
		List<Product> myList=query.getResultList();
		
		return myList;
	}

}
