package com.cg.springmvcdem.dao;

import java.util.List;

import com.cg.springmvcdem.dto.Product;

public interface ProductDao {
	
	public Product save(Product pro);
	public List<Product> showProduct();

}
