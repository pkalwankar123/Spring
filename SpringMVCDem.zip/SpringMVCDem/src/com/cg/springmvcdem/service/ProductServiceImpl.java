package com.cg.springmvcdem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdem.dao.ProductDao;
import com.cg.springmvcdem.dao.ProductDaoImpl;
import com.cg.springmvcdem.dto.Product;
@Service
@Transactional
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDao productdao;
	
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productdao.save(pro);
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return productdao.showProduct();
	}

}
