package com.cg.springmvcdem.service;


import java.util.List;

import com.cg.springmvcdem.dto.Product;

public interface ProductService {
	
	public Product addProduct(Product pro);
	public List<Product> showProduct();

}
