package com.cg.ProductSpringBoot.service;

import java.util.List;

import com.cg.ProductSpringBoot.dto.Product;

public interface Productservice {
	public Product addProduct(Product pro);
	public List<Product> showAll();
	public Product searchbyid(int id);

}
