package com.cg.ProductSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductSpringBoot.dto.Product;
import com.cg.ProductSpringBoot.service.Productservice;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	Productservice productservice;
	
	
	@RequestMapping(value="/checkname/{uname}",method=RequestMethod.GET)
	//@GetMapping("checkname")
	public String getName(@PathVariable("uname")String mname,@RequestParam("prodid")String id) {
		System.out.println("helooooo");
		return id+"Capgemini" +mname;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("prodid")String pid,@RequestParam("prodName")String name,@RequestParam("prodPrice")String pprice) {
		
		System.out.println(pid+""+name+""+pprice+"");
		return "Welcome";
	}
	
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product pro) {
		productservice.addProduct(pro);
		return pro;
	}
	
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public List<Product> showAllProduct(){
		return productservice.showAll();
	}
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product searchProduct(@RequestParam("id")String id){
		//System.out.println(id);
		int a=Integer.parseInt(id);
		//System.out.println(productservice.searchbyid(a));
		return productservice.searchbyid(a);
	}
	
	
	
	
}
