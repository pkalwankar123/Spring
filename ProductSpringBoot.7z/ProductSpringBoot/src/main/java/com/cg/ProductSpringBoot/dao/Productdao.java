package com.cg.ProductSpringBoot.dao;

import java.util.List;

import com.cg.ProductSpringBoot.dto.Product;

public interface Productdao {
	public Product save(Product pro);
	public List<Product> showAll();
	public Product findbyid(int id);
}
