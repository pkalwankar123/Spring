package com.cg.Demoonespringcore.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Demoonespringcore.dto.Item;
import com.cg.Demoonespringcore.dto.Product;



public class Mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext app=new ClassPathXmlApplicationContext("ABC.xml");
		
		Product p=(Product) app.getBean("prod");
		/*p.setId(1001);
		p.setName("Danish");
p.setPrice(1000.00);
p.setDescription("Sonny");
		*/
		p.getAllData();
		
		
		
	/*	Product p1=(Product) app.getBean("prod");
		p1.getAllData();
		
		
		
		Item i=(Item) app.getBean("item");
		i.getAllItemData();*/
	}

}
