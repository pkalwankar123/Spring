package com.cg.demo.dto;

public class Product {

	
	
	private Integer id;
	private String name;
	private String desc;
	private String categ;
	private Double price;
	
	public Product() {
	
	}


	public Product(Integer id, String name, String desc, String categ, Double price) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
		this.categ = categ;
		this.price = price;
	}


	

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getCateg() {
		return categ;
	}


	public void setCateg(String categ) {
		this.categ = categ;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", desc=" + desc + ", categ=" + categ + ", price=" + price
				+ "]";
	}


	
	
	
}
