package com.cg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ProductDao;
import com.cg.demo.dto.Product;


@Service
public class ProductServiceImpl implements ProductService {

	
	@Autowired
	ProductDao dao;
	
	@Override
	public Product addproduct(Product prod) {

		return dao.save(prod);
	}

	@Override
	public List<Product> show() {
	
		return dao.show();
	}

	@Override
	public Product searchid(int id) {

		return dao.findById(id);
	}

	@Override
	public Product update(Product prod) {
		
		return dao.update(prod);
	}

	@Override
	public void delete(Product prod) {
		// TODO Auto-generated method stub
		dao.delete(prod);
	}
	
}
	