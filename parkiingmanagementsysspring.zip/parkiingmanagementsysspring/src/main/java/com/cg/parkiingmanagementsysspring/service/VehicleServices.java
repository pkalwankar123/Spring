package com.cg.parkiingmanagementsysspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.Vehiclerepositoryinterface;
import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.VehicleNotFoundException;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;
import com.cg.parkiingmanagementsysspring.util.DButil;

@Service("vehicleService")
public class VehicleServices implements Vehicleservice{
	Vehiclerepositoryinterface vehdao;

@Autowired
	public void setVehdao(Vehiclerepositoryinterface vehdao) {
		this.vehdao = vehdao;
	}


	public void add(Vehicle vehicle)  {
		
		
		
				vehdao.save(vehicle);	
			}
			
			
		
		
	

	
	public Vehicle searchbyVehNo(String vehNo) throws VehicleNotFoundException {
		
		if(vehdao.findByVehNo(vehNo)==null){
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
		
		}else
		
			return vehdao.findByVehNo(vehNo);
	}

}
