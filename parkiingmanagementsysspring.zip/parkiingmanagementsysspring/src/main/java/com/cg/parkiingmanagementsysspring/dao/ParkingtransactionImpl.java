package com.cg.parkiingmanagementsysspring.dao;

import org.springframework.stereotype.Repository;

import com.cg.parkiingmanagementsysspring.dto.Parkingslot;
import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;
import com.cg.parkiingmanagementsysspring.util.DButil;

@Repository("parkingTransaction")
public class ParkingtransactionImpl implements Parkingtransactionrepointerface{


	public Parktransaction book(Parktransaction parktrans1) throws invaliddetailexcepion{

		/*for(Parkingslot parkk: DButil.parkingslot) {
			if (((parktrans1.getStartTime()).isBefore(parkk.getStartTime())) || ((parktrans1.getStartTime()).isAfter(parkk.getEndTime())) )  {
				
				
				
				throw new invaliddetailexcepion("OOPS..Slot is not available, Please enter the timings between "+(parkk.getStartTime())+" to "+(parkk.getEndTime()));
				}
			
			}
		
		
			for(Parktransaction owe1:DButil.parktrans){
				
				
				if ((((parktrans1.getStartTime()).isAfter(owe1.getStartTime())) && ((parktrans1.getStartTime()).isBefore(owe1.getEndTime())) ) || ((owe1.getStartTime().equals(parktrans1.getStartTime())) || (owe1.getEndTime().equals(parktrans1.getEndTime())))) {
				
					
					
						throw new invaliddetailexcepion("OOPS..Slot is alreaddy booked between "+owe1.getStartTime()+" to "+owe1.getEndTime());
						}
				
			}*/
		
		
		DButil.parktrans.add(parktrans1);
		
		return parktrans1;
	}

}
