package com.cg.parkiingmanagementsysspring.dto;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("parkingslot")
@Scope("prototype")
public class Parkingslot {

	private int id;
	@Autowired
	private Parking parking;
	
	
	
	private Date startDate;
	private Date endDate;
	
	private Time startTime;
	
	private Time endTime;

	
	public Parkingslot(){}
	public Parkingslot(int id, Parking parking, Date startDate, Date endDate,Time startTime, Time endTime) {
		super();
		this.id = id;
		this.parking = parking;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Parking getParking() {
		return parking;
	}
	public void setParking(Parking parking) {
		this.parking = parking;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public Time getStartTime() {
		return startTime;
	}
	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}
	public Time getEndTime() {
		return endTime;
	}
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "Parkingslot [id=" + id + ", parking=" + parking + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
		
	
	
	
}
