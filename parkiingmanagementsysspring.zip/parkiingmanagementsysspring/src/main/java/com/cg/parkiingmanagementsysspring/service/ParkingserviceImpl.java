package com.cg.parkiingmanagementsysspring.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.ParkingrepositoryImpl;
import com.cg.parkiingmanagementsysspring.dto.Parking;

@Service("parkingService")
public class ParkingserviceImpl implements Parkingserviceinterface{

	
	ParkingrepositoryImpl parkRepository;
	
	
	
@Autowired
	public void setParkRepository(ParkingrepositoryImpl parkRepository) {
		this.parkRepository = parkRepository;
	}



	public ParkingserviceImpl(){
		parkRepository=new ParkingrepositoryImpl();
	}
	
	

	public void addParking(Parking parking) {

		parkRepository.save(parking);
	}

}

