package com.cg.parkiingmanagementsysspring.dao;

import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;

public interface Parkingtransactionrepointerface {
public Parktransaction book(Parktransaction park) throws invaliddetailexcepion;
}
