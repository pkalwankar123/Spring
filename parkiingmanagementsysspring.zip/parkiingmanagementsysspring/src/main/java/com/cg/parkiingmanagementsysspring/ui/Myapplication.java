package com.cg.parkiingmanagementsysspring.ui;

import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.parkiingmanagementsysspring.config.JavaConfig;
import com.cg.parkiingmanagementsysspring.dto.Address;
import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Parking;
import com.cg.parkiingmanagementsysspring.dto.Parkingslot;
import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.VehicleNotFoundException;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;
import com.cg.parkiingmanagementsysspring.service.OwnerNotFoundException;
import com.cg.parkiingmanagementsysspring.service.Ownerserviceinterface;
import com.cg.parkiingmanagementsysspring.service.Parkingserviceinterface;
import com.cg.parkiingmanagementsysspring.service.Parkingslotinterface;
import com.cg.parkiingmanagementsysspring.service.Parkingtransserivceinterface;
import com.cg.parkiingmanagementsysspring.service.Parkingtransservice;
import com.cg.parkiingmanagementsysspring.service.VehicleServices;
import com.cg.parkiingmanagementsysspring.service.Vehicleservice;
import com.cg.parkiingmanagementsysspring.util.DButil;
//import com.cg.parkingmanagementsys.exception.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.Invaliddateexcepion;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;


public class Myapplication {

	public static void main(String[] args) throws ParseException {
		
		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(JavaConfig.class);
	
		Owner owner=(Owner)appContext.getBean("owner");
		Parking parking=(Parking)appContext.getBean("parking");
		Ownerserviceinterface oweservice=(Ownerserviceinterface) appContext.getBean("ownerService");
		Vehicleservice vehservice=(Vehicleservice)appContext.getBean("vehicleService");
		Parkingserviceinterface parkService=(Parkingserviceinterface)appContext.getBean("parkingService");
		Parkingslot parkslot=(Parkingslot)appContext.getBean("parkingslot");
		Parkingslotinterface parkingslotService=(Parkingslotinterface)appContext.getBean("parkingslotService");
		Parkingtransserivceinterface parktransService=(Parkingtransserivceinterface)appContext.getBean("parkingtransactionService");
		Parktransaction parktranss=(Parktransaction)appContext.getBean("parkingtransaction");
		Vehicle vehicleOne=(Vehicle)appContext.getBean("vehicle");
		Owner ownerOne=null;
		Parking pars=null;
		/*VehicleServices vehsservice=new VehicleServices();
		Parkingservice parkservice=new Parkingservice();
		Parkingslotservice parkslotservice=new Parkingslotservice();
		Parkingtransservice parktrans=new Parkingtransservice();*/
		
		int choice=0;
do{
		Scanner sc=new Scanner(System.in);
		System.out.println("================================================");
		System.out.println();
		System.out.println("========= Parking Management System ===========");
		System.out.println();
		System.out.println("================================================");
		System.out.println("=============== WELCOME ========================");
		System.out.println("1. Add Owner");
		System.out.println("2. Add Vehicles");
		System.out.println("3. Search Vehicles");
		System.out.println("4. Add Parking Location");
		System.out.println("5. Add Parkingslot");
		
		System.out.println("6. Assign Parking");
		System.out.println("7. Exit");
		System.out.println();
		System.out.println("================================================");
	
		choice=sc.nextInt();
		
		
		switch(choice){
		case 1: 
			System.out.println("Enter the ownerId");
			int ID=sc.nextInt();
			System.out.println("enter the name");
			String name=sc.next();
			System.out.println("enter the Mobile number");
			String mobNumber=sc.next();
			System.out.println("enter the house no");
			String houseno=sc.next();
			System.out.println("enter the Street");
			String street=sc.next();
			System.out.println("enter the city");
			String city=sc.next();
			System.out.println("enter the Pincode");
			int pincode=sc.nextInt();
			
			//address object for setting into owner
			Address address=(Address)appContext.getBean("address");
			
			
			owner.setID(ID);
			owner.setName(name);
			owner.setmobNumber(new BigInteger(mobNumber));
			address.setHouseNo(houseno);
			address.setStreet(street);
			address.setCity(city);
			address.setPincode(pincode);
			
			
			
				oweservice.addOwner(owner);
			
			
			System.out.println("================================");
			System.out.println();
			System.out.println("Owner Added successfully!!!!");
			System.out.println();
			System.out.println("=================================");
		
			
			
			
			for(Owner owe:DButil.owner){
										
				System.out.println(owe.getOwnerDetails());
				System.out.println("=================================");
			}
			
			
			break;	

		case 2: 
			char ch=0;
			
			System.out.println("enter owner ID");
			int oweid=sc.nextInt();
			
			
			try {
				ownerOne=oweservice.searchbyId(oweid);
			} catch (OwnerNotFoundException e1) {
				System.out.println(e1.getMessage());
				break;
			}
			do {
				Vehicle vehicle=(Vehicle)appContext.getBean("vehicle");
			System.out.println("enter vehicle number");
			String vehno=sc.next();
			System.out.println("enter vehicle desciption");
			String vedesc=sc.next();
				
					
					ownerOne.setID(oweid);
					vehicle.setOwner(ownerOne);
					vehicle.setVehNo(vehno);
					vehicle.setVehDesc(vedesc);
					vehservice.add(vehicle);
			
				System.out.println("Do you want to assign another vehicle??  Y/N");
				ch=sc.next().charAt(0);
				System.out.println();
		}while(ch=='Y'||ch=='y');
		
					
			
					
					
		
				
				
			
			
				System.out.println("================================");
				System.out.println();
				System.out.println("Vehicles Added successfully!!!!");
				System.out.println();
				System.out.println("=================================");
				
				
				for(Vehicle owe:DButil.vehicle){
					
					System.out.println("Vehicle Number :- "+owe.getVehNo());
					System.out.println("Vehicle Description :- "+owe.getVehDesc());
				System.out.println("Owner detail related to vehicle :- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				
				break;
			
			
			
			
			
			case 3:
				System.out.println();
				System.out.println("=================================");
				System.out.println("Enter Vehicle number that you want too search");
				String vehNo=sc.next();
			Vehicle vehicle;
			try {
				vehicle = vehservice.searchbyVehNo(vehNo);
				
				System.out.println("Here is your Vehicle detail...");
				System.out.println();
				System.out.println(vehicle.vehicleDetails());
				
			} catch (VehicleNotFoundException e) {
				
				System.out.println(e.getMessage());
			}
			System.out.println("=================================");
				break;
			
			case 4:
				System.out.println("=================================");
				System.out.println("enter owner ID");
				int oweidOne=sc.nextInt();
				
				try {
					ownerOne=oweservice.searchbyId(oweidOne);
				} catch (OwnerNotFoundException e1) {
					System.out.println(e1.getMessage());
					break;
				}
				
				System.out.println("enter Parking ID");
				int powid=sc.nextInt();

				System.out.println("enter the Parking Location");
				String plocation=sc.next();
		
				ownerOne.setID(oweidOne);
				parking.setOwner(ownerOne);
				parking.setId(powid);
				parking.setLocation(plocation);
				
				
				
				parkService.addParking(parking);;
				
				System.out.println("Parking location Added successfullly!!!");
				System.out.println();
				for(Parking owe:DButil.parking){
					System.out.println("Parking id:- "+owe.getId());
					System.out.println("Parking Location:- "+owe.getLocation());
					
					
				System.out.println("Owner Detail:- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				break;
case 5:
	System.out.println("=================================");
	
	
	
	
	
	
	System.out.println("enter the Parking id");
	int pd=sc.nextInt();

	
	
	System.out.println("enter the Parkingslot id");
	int psid=sc.nextInt();
	
	System.out.println("enter the start date for Parkingslot");
	String startdate=sc.next();
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    LocalDate startdate1 = LocalDate.parse(startdate, formatter);

    java.sql.Date sd=java.sql.Date.valueOf(startdate1);
    
	if(validatenew(startdate)) {
		if((isvalidatenew(startdate)) || (isToday(startdate))) {
		System.out.println();
	}else {
		try {
			throw new invaliddetailexcepion("OOPs...you have entered the earlier date!!"
					+ "Please try again with valid date!!!");
		} catch (invaliddetailexcepion e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
		}
	else {
		try {
			throw new invaliddetailexcepion("OOPs...please check the date that you have entered!!"
					+ "Please try again with valid date");
		} catch (invaliddetailexcepion e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}			}
	
	

        		        
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        
        
        System.out.println("enter the end date for Parkingslot");
		String enddate=sc.next();
	
		
		if(validatenew(enddate)) {
			if((isvalidatenew(enddate)) || (isToday(enddate))) {
			System.out.println();
		}else {
			try {
				throw new invaliddetailexcepion("OOPs...you have entered the earlier date!!"
						+ "Please try again with valid date!!!");
			} catch (invaliddetailexcepion e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				break;
			}
		}
			}
		else {
			try {
				throw new invaliddetailexcepion("OOPs...please check the date that you have entered!!"
						+ "Please try again with valid date");
			} catch (invaliddetailexcepion e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				break;
			}			}
		
		
		
		LocalDate enddate1 = LocalDate.parse(enddate, formatter1);
		//LocalDate formatDateTime = LocalDate.parse(enddate, formatter);
	

	
	
	
		DateTimeFormatter formatternew = DateTimeFormatter.ofPattern("HH:mm");
	
	System.out.println("Enter time slot, start time in hrs and minutes:");
	System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
String starttime=sc.next();
LocalTime  starttime1= LocalTime.parse(starttime, formatternew);



System.out.println("Till how many hrs you want to create ParkingSlot");
int patternOne=sc.nextInt();


LocalTime endTime1 = starttime1.plusHours(patternOne);
	

//LocalTime endTime1 = LocalTime.parse(patternOne, formatternew);






java.sql.Date ed=java.sql.Date.valueOf(enddate1);


Time st=Time.valueOf(starttime1);


Time et=Time.valueOf(endTime1);

//Myapplication my=new Myapplication();
//my.validateq(sd);
		
		 //if (validateq(sd)) { System.out.println(); } else { System.out.println("no");
		 // break; }
		


parking.setId(pd);

//paParkingslot parks=new Parkingslot(psid,pars,sd,ed,st,et);

	parkslot.setId(psid);
	parkslot.setParking(parking);
	parkslot.setStartDate(sd);
	parkslot.setEndDate(ed);
	parkslot.setStartTime(st);;
	parkslot.setEndTime(et);
	
	

	
	
	
			
				
					parkingslotService.createParkingslot(parkslot);
				
			
	
				System.out.println("Parking slot created successfullly");
				System.out.println();
				for(Parkingslot owe:DButil.parkingslot){
					System.out.println("ParkingSlot ID:- "+owe.getId());
					System.out.println("Parkingslot for "+owe.getParking());
					System.out.print("ParkingSlot creator detail:- "+owe.getParking().getOwner().ownerDetails());
					System.out.println();
					System.out.println("Start date of parkingslot:- "+owe.getStartDate());
					System.out.println("End date of parkingslot:- "+owe.getEndDate());
					System.out.println("Start time of parkingslot:- "+owe.getStartTime());
					System.out.println("End time of parkingslot:- "+owe.getEndTime());						
					System.out.println();
					System.out.println("=================================");
				}
	
	
	
	
				break;
				

	
case 6:
	char ch1;
	do {


System.out.println("=================================");
System.out.println();
System.out.println("Enter parking transaction id");
int pid1=sc.nextInt();

System.out.println("Enter parkingslot id");
int id1=sc.nextInt();
//System.out.println();
System.out.println("Enter Vehicle number");
String vehNoone=sc.next();


System.out.println("enter the start date for Parkingslot");
String startdateOne=sc.next();



if(validatenew(startdateOne)) {
if((isvalidatenew(startdateOne)) || (isToday(startdateOne))) {
System.out.println();
}else {
try {
	throw new invaliddetailexcepion("OOPs...you have entered the earlier date!!"
			+ "Please try again with valid date!!!");
} catch (invaliddetailexcepion e) {
	// TODO Auto-generated catch block
	System.out.println(e.getMessage());
	break;
}
}
}
else {
try {
	throw new invaliddetailexcepion("OOPs...please check the date that you have entered!!"
			+ "Please try again with valid date");
} catch (invaliddetailexcepion e) {
	// TODO Auto-generated catch block
	System.out.println(e.getMessage());
	break;
}			}


DateTimeFormatter formatterOne = DateTimeFormatter.ofPattern("dd-MM-yyyy");

LocalDate startdateOnenew = LocalDate.parse(startdateOne, formatterOne);

DateTimeFormatter formatternew1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");


System.out.println("enter the end date for Parkingslot");
String enddateOne=sc.next();


if(validatenew(enddateOne)) {
	if((isvalidatenew(enddateOne)) || (isToday(enddateOne))) {
	System.out.println();
}else {
	try {
		throw new invaliddetailexcepion("OOPs...you have entered the earlier date!!"
				+ "Please try again with valid date!!!");
	} catch (invaliddetailexcepion e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
		break;
	}
}
	}
else {
	try {
		throw new Exception("OOPs...please check the date that you have entered!!"
				+ "Please try again with valid date");
	} catch (invaliddetailexcepion e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
		break;
	}			}


LocalDate enddateOnenew = LocalDate.parse(enddateOne, formatternew1);
//LocalDate formatDateTime = LocalDate.parse(enddate, formatter);





DateTimeFormatter formatternew2 = DateTimeFormatter.ofPattern("HH:mm");

System.out.println("Enter time slot, start time in hrs and minutes:");
System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
String starttimenew=sc.next();
LocalTime  starttimenew1= LocalTime.parse(starttimenew, formatternew2);



System.out.println("Till how many hrs you want to create ParkingSlot");
int patternOnenew=sc.nextInt();


LocalTime endTimenew1 = starttimenew1.plusHours(patternOnenew);











System.out.println();
//Vehicle vehee=new Vehicle();
Vehicle vehicleTwo=(Vehicle)appContext.getBean("vehicle");
//Parkingslot paki=new Parkingslot();

List<Vehicle> vehicle1;
try {
vehicle1 = vehservice.searchbyVehNo(vehNoone);
for(Vehicle vehic:vehicle1) {
	if(vehic.getnumber().equals(vehNoone)){
		vehee=vehic;
}}
} catch (VehicleNotFoundException e1) {

System.out.println(e1.getMessage());
break;
} 

List<Parkingslot> park;
try {
park = parkslotservice.searchByid(id1);
for(Parkingslot par:park){
	if(par.getId()==id1) {
		
		paki=par;
		
				}
}
} catch (ParkingNotFoundException e1) {
// TODO Auto-generated catch block
System.out.println(e1.getMessage());
break;
}



try {
if(vehee.getnumber()==null || paki.getId()!=id1){
throw new invaliddetailexcepion("OOPS!!..You have entered the wrong ID or Vehicle Number."
		+ "Please enter the valid detail and try again!!!");}
} catch (invaliddetailexcepion e) {

System.out.println(e.getMessage());
break;
}
//LocalTime pstartTime1 = LocalTime.of(patternp, patterntwop);
//LocalTime pendTime1 = pstartTime1.plusHours(patternOnep);




//LocalDate pstartDate1 = LocalDate.of(pyear,pmonth,pday);
//LocalDate pendDate1 = LocalDate.of(pyear1,pmonth1,pday1);
java.sql.Date psd=java.sql.Date.valueOf(startdateOnenew);

java.sql.Date ped=java.sql.Date.valueOf(enddateOnenew);


Time pst=Time.valueOf(starttimenew1);


Time pet=Time.valueOf(endTimenew1);



Parktransaction parktranss=new Parktransaction(pid1,paki,vehee,psd,ped,pst,pet);



	
		
			try {
				parktrans.bookParking(parktranss);
			} catch (com.cg.parkingmanagementsystem.exceptions.InvaliddetailId e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				break;
			}
		
		
	 catch (invaliddetailexcepion e) {
		
		System.out.println(e.getMessage());
		break;
	}
		
		System.out.println("Parking assigned to below users successfullly..!!!");
		
		/*for(Parktransaction owe:DButil.parktrans){
			System.out.println("Parking transaction ID:- "+owe.getId());
			System.out.println(owe.getPk());
			System.out.print(owe.getVeh().vehicleDetails());
			System.out.println();
			System.out.println("Start date:- "+owe.getStartDate());
			System.out.println("End date:- "+owe.getEndDate());
			System.out.println("Start Time:- "+owe.getStartTime());
			System.out.println("End Time:- "+owe.getEndTime());
			System.out.println();			
		}*/
		System.out.println("================================================");
		
		System.out.println("Do you want to assign another vehicle??  Y/N");
		ch=sc.next().charAt(0);
		System.out.println();
}while(ch=='Y'||ch=='y');
		break;		
				
case 7:
	System.out.println("======= Thank you ======");
	System.exit(0);
			break;
			
			default:
				System.out.println("Oops..Invalid input."
						+ "Please enter the correct choice from the list!!!");
		}
	
	}while(choice!=6);

}
	
	static boolean validatenew(String date) {
		SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		datef.setLenient(false);
		try {
			datef.parse(date.trim());
		}
		catch(ParseException p) {
			return false;
			
		}
		
		return true;
	}
	static boolean isvalidatenew(String date) throws ParseException {
		SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		Date date1=datef.parse(date);
		
		return new Date().before(date1);
			}
	static boolean isToday(String date) throws ParseException {
SimpleDateFormat datef=new SimpleDateFormat("dd-MM-yyyy");
		
		Date date1=datef.parse(date);
		
		return new Date().equals(date1);
		
	}
// Driver code 

	private static boolean isSameDay(Date date1, Date date2) {
		// TODO Auto-generated method stub
		Calendar cal1=Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2=Calendar.getInstance();
		cal1.setTime(date2);
		
		
		return isSameDay(cal1,cal2);
	}

	private static boolean isSameDay(Calendar cal1, Calendar cal2) {
		// TODO Auto-generated method stub
		return (cal1.get(Calendar.YEAR)==cal2.get(Calendar.YEAR)&&
				cal1.get(Calendar.MONTH)==cal2.get(Calendar.MONTH)&&
				cal1.get(Calendar.DAY_OF_MONTH)==cal2.get(Calendar.DAY_OF_MONTH));
	}

}

