package com.cg.parkiingmanagementsysspring.dao;

import com.cg.parkiingmanagementsysspring.dto.Parkingslot;

public interface Parkingslotrepositoryinterface {
public Parkingslot create(Parkingslot parkslot);
}

