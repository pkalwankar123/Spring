package com.cg.parkiingmanagementsysspring.dao;



import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.exceptions.Duplicateaddressuserexception;


public interface Ownerdaorepositoryinterface {

	public Owner save(Owner owner);
	
	public Owner findByID(int id);
}
