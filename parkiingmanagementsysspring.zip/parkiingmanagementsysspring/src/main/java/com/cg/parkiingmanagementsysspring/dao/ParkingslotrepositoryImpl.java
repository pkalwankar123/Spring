package com.cg.parkiingmanagementsysspring.dao;

import org.springframework.stereotype.Repository;

import com.cg.parkiingmanagementsysspring.dto.Parkingslot;
import com.cg.parkiingmanagementsysspring.util.DButil;

@Repository("parkingslotRepository")
public class ParkingslotrepositoryImpl implements Parkingslotrepositoryinterface{


	public Parkingslot create(Parkingslot parkslot) {

		DButil.parkingslot.add(parkslot);
		
		return parkslot;
	}

}
