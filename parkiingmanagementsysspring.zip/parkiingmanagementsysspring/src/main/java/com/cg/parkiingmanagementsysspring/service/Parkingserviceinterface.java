package com.cg.parkiingmanagementsysspring.service;

import com.cg.parkiingmanagementsysspring.dto.Parking;

public interface Parkingserviceinterface {

	public void addParking(Parking parking);
	
}
