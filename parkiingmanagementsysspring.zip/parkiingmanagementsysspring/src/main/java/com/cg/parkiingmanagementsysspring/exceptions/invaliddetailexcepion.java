package com.cg.parkiingmanagementsysspring.exceptions;

public class invaliddetailexcepion extends Exception {

	public invaliddetailexcepion(){}
	
	public invaliddetailexcepion(String message){
		super(message);
	}
	
}
