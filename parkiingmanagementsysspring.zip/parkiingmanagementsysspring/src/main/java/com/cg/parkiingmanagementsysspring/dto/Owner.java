package com.cg.parkiingmanagementsysspring.dto;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("owner")
public class Owner {
private int ID;
	private String name;
	private BigInteger mobNumber;
	private List<Vehicle> vehicles;
	@Autowired
	private Address address;
	
	public Owner(){}

	public Owner(int ID,String name, BigInteger mobNumber, List<Vehicle> vehicles, Address address) {
		super();
		this.ID = ID;
		this.name = name;
		this.mobNumber = mobNumber;
		this.vehicles = vehicles;
		this.address = address;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getmobNumber() {
		return mobNumber;
	}

	public void setmobNumber(BigInteger mobNumber) {
		this.mobNumber = mobNumber;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Address getAddress() {
		return address;
	}

	
	public void setAddress(Address address) {
		this.address = address;
	}

	
	public String getOwnerDetails(){
		StringBuilder sb = new StringBuilder();	
		sb.append("Owner:- "+this.ID);
		sb.append(" ");
		sb.append("Owner:- "+this.name);
		sb.append(" ");
		sb.append("Mob no.:- "+this.mobNumber);
		sb.append(" ");
		sb.append(this.address.toString());
		sb.append(" ");
		/*for(Vehicle s : this.vehicles) {
			sb.append(s.vehicleDetails());
		}*/
		
		return sb.toString();
		
	}
	
	public String ownerDetails() {
		return this.ID + " "+this.name + " "+ this.mobNumber + " "+ this.address.toString();
	}

	

	
}

