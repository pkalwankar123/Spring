package com.cg.parkiingmanagementsysspring.service;

import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.VehicleNotFoundException;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;


public interface Vehicleservice {

	public void add(Vehicle vehicle);
	public Vehicle searchbyVehNo(String vehNo) throws VehicleNotFoundException;
}
