package com.cg.parkiingmanagementsysspring.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("parking")
@Scope("prototype")
public class Parking {
	private int id;
	private String Location;
	@Autowired
	private Owner owner;
	
	public Parking (){}

	public Parking(int id, String location, Owner owner) {
		super();
		this.id = id;
		Location = location;
		this.owner = owner;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "parking [id=" + id + ", Location=" + Location + "]";
	}
	
}
