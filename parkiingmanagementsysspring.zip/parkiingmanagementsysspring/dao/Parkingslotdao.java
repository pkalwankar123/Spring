package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parkingslot;

public interface Parkingslotdao {
public Parkingslot create(Parkingslot parkslot);
}

