package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parking;

public interface Parkingdaointerface {

	public Parking save(Parking park);
	
}
