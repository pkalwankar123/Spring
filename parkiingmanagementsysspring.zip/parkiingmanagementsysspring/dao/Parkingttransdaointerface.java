package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public interface Parkingttransdaointerface {
public Parktransaction book(Parktransaction park) throws invaliddetailexcepion;
}
