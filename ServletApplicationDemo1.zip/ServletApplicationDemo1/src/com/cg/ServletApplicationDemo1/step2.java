package com.cg.ServletApplicationDemo1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class step2
 */
@WebServlet("/step2")
public class step2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public step2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String guestname=request.getParameter("guestname");
		
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Greetings</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h2>Welcome!!</h2>");
		//out.println("<p> Error Status code"++"</p>");
		out.println("<p> welcome "+guestname+"</p>");
		
		out.println("<form name='fm1' action='preview' method='post'>");
		
		out.println("<input type='hidden' name='guestname' value='"+guestname+"'/>");
		out.println("<p>enter the guest name:</p>");
		out.println("<p><input type='email' name='email'/></p>");
		out.println("<p><input type='submit' name='Submit' value='button'/></p>");
		out.println("</form>");
		
		
		out.println("</body>");
		out.println("</html>");
		
		
	}

}
