package com.cg.ProductSpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProductSpringBoot.dao.ProductDaoOne;

import com.cg.ProductSpringBoot.dto.Product;
@Service
public class Productserviceimpl implements Productservice {
@Autowired
ProductDaoOne productDao;
	
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productDao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	/*@Override
	public Product searchbyid(int id) {
		// TODO Auto-generated method stub
		return productDao.
	}*/
	
	public List<Product> findByname(String name){
		return productDao.findByname(name);
		
	}
	
	
	public List<Product> findByPriceBetween(double priceOne, double priceTwo){
		return productDao.findByPriceBetween(priceOne, priceTwo);
		
	}

}
