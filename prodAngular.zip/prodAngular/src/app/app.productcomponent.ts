import { Component,OnInit} from "@angular/core";
import { ProductService } from "./app.ProductService";
import { Product } from "./app.Product";


@Component({
selector:'prod-app',
templateUrl:'app.product.html'

})
export class ProductComponent implements OnInit{

    products:Product[];
    pro:any={
        "id":1008,"name":"abc","price":1444.11,"description":"good",
        "inventory":{
            "id":109,
            "name":"good"
        }
    }
constructor(private proservice:ProductService){}
    

ngOnInit(){
    this.proservice.getAllProduct().subscribe((data:Product[])=>this.products=data);
}

addProduct(){
    this.proservice.addAllProduct(this.pro).subscribe((data)=>console.log(data));
}


}