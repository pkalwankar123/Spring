import {Inventory} from './app.inventory'

export class Product{
    id:number;
    name:string;
    price:number;
    description:string;
inventory:Inventory;
}