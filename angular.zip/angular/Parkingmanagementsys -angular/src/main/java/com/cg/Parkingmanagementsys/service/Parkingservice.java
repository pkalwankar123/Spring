package com.cg.Parkingmanagementsys.service;

import java.util.List;

import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.exceptions.Invalidowneridexception;
import com.cg.Parkingmanagementsys.exceptions.Invaliparkingidexception;

/*
 * Parkingservice interface Service
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */

public interface Parkingservice {
	public Parking add(Parking parking);
	public List<Parking> searchbyid(int id) throws Invaliparkingidexception;
	
}
