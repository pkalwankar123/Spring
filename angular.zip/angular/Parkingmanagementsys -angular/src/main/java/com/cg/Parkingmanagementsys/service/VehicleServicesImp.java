package com.cg.Parkingmanagementsys.service;

import java.awt.Window.Type;
import java.sql.SQLException;
import java.util.List;


import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Vehicledao;
import com.cg.Parkingmanagementsys.dto.Vehicle;
import com.cg.Parkingmanagementsys.exceptions.Invalidvehiclenumexception;





@Service
@Transactional
public class VehicleServicesImp implements Vehicleservice {
	static final Logger logger = Logger.getLogger(ParkingtransactionImpl.class); 
	
	/*
	 * Autowired: for injecting the dao methods 
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Autowired
	 Vehicledao vehdao;

	
	
	public Vehicle add(Vehicle vehicle) {
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		logger.info("Vehicle added successful");

		/*
		 * @return: return the data from the dao
		 *@author: Pradip kalwankar 
		 *@since: 2019-05-23
		 */	
		return vehdao.save(vehicle);
	}

	/*
	 * findBynumber: for finding the number
	 * @Exception: throws exception if id not found to controller
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	public List<Vehicle> findBynumber(String number) throws Invalidvehiclenumexception {
		
			PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		if(vehdao.findBynumber(number).isEmpty()){
		logger.info("Searching vehicle....");
			throw new Invalidvehiclenumexception("OOPS..Vehicle not found into the Database."
					+ " Please enter the valid Vehicle number and try again!!");
			
		}else {
			/*
			 * @return: return the data from the dao
			 *@author: Pradip kalwankar 
			 *@since: 2019-05-23
			 */	
		return vehdao.findBynumber(number);
	}

	}
		
}

