package com.cg.Parkingmanagementsys.exceptions;

public class Invaliparkingidexception extends Exception {

public Invaliparkingidexception() {}
	
	public Invaliparkingidexception(String msg) {
		super(msg);
	}
	
	
	
}
