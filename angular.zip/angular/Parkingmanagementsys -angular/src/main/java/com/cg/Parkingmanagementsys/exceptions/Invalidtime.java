package com.cg.Parkingmanagementsys.exceptions;

public class Invalidtime extends Exception{
public Invalidtime() {}
	
	public Invalidtime(String msg) {
		super(msg);
	}
}
