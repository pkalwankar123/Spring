package com.cg.Parkingmanagementsys.exceptions;

public class Invaliddate extends Exception{
public Invaliddate() {}
	
	public Invaliddate(String msg) {
		super(msg);
	}
}
