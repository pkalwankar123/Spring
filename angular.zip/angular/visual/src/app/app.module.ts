﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule }  from '@angular/forms';
import { OwnerComponent }  from './app.ownercomponent';
import { VehicleComponent }  from './app.vehiclecomponent';
import { ParkingService }  from './app.parkingservice';
import{Routes,RouterModule}from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';



const route:Routes=[

    {path:"addOwner",component:OwnerComponent},
    {path:"addVehicle",component:VehicleComponent}
];

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,RouterModule.forRoot(route),
        ReactiveFormsModule
        
    ],
    declarations: [
        AppComponent,
        OwnerComponent,VehicleComponent
      
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }