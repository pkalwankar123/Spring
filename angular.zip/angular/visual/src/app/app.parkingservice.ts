import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from "rxjs"
import { Owner } from './app.owner';
import { Vehicle } from './app.vehicle';
@Injectable({
    providedIn:'root'
})
export class ParkingService{
   
    constructor(private http:HttpClient){}
   
    
    addAllOwner(userdata:any){
        let input=new FormData();
        input.append("id",userdata.ownerid);
        input.append("name",userdata.ownerName);
        input.append("mobNumber",userdata.ownerCantact);
        input.append("address.houseNumber",userdata.ownerHousnumber);
        input.append("address.street",userdata.ownerStreet);
        input.append("address.city",userdata.ownerCity);
        input.append("address.pincode",userdata.ownerPincode);
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addowner",input);
    }
    
    addAllVehicle(vehicle:any){
        let input=new FormData();
        input.append("owner.id",vehicle.ownerid);
        input.append("number",vehicle.number);
        input.append("description",vehicle.description);
        
       
        return this.http.post("http://localhost:9091/parkingmgtsys/addvehicle",input)
    }

    }