
import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
import { Owner } from "./app.owner";
import { Vehicle } from "./app.vehicle";


@Component({
selector:'vehicle-app',
templateUrl:'app.vehicle.html'

})
export class VehicleComponent {

    
    number:string;
    description:string;
   ownerid:Owner
    

    constructor(private veheservice:ParkingService){}

    vehicle:any={
       
    };

   // addVehicle(){
     //   this.veheservice.addAllVehicle(this.vehicle).subscribe((data)=>console.log(data));
    //}
}
