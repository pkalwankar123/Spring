package com.cg.labassignmentspring.service;

import java.util.List;

import com.cg.labassignmentspring.dto.Trainee;

public interface TraineeService {

	public Trainee addTrainee(Trainee trainee);

	public void removeTrainee(Trainee trainee);

	public Trainee updateTrainee(Trainee trainee);

	public Trainee searchTraineeById(Integer id);

	public List<Trainee> showAllTrainee();

}
